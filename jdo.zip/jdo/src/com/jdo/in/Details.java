package com.jdo.in;

public class Details {

}
