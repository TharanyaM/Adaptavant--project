/*package com.project.in.models;

import javax.inject.Inject;
import javax.jdo.annotations.PersistenceCapable;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("session")
@PersistenceCapable
public class Live {
	@Inject
	private User endUser;

	public User getEndUser() {
		return endUser;
	}

	public void setEndUser(User endUser) {
		this.endUser = endUser;
	}

}*/
