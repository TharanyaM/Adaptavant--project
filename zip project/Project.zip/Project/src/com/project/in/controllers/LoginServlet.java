package com.project.in.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class LoginServlet {
	
	@RequestMapping(value="/",method = RequestMethod.GET)
	public String login()
	{
		return "index";
		
	}
	
	
	@RequestMapping(value="/verify", method = RequestMethod.POST)
	public String verify()
	{
		return "home";
		
	}
	
	

}
